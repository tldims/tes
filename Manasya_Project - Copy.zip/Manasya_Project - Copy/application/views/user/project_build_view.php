<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from preview.colorlib.com/theme/engineers/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 23 Nov 2020 02:37:14 GMT -->

<head>
    <title>PT MANASYA ANUGERAH SEJAHTERA</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Oswald:300,400,700|Muli:300,400" rel="stylesheet">
    <link rel="stylesheet" href="/Manasya_Project/assets/user/fonts%2c_icomoon%2c_style.css%2bcss%2c_bootstrap.min.css%2bcss%2c_jquery-ui.css%2bcss%2c_owl.carousel.min.css%2bcss%2c_owl.theme.default.min.css%2bcss%2c_owl.theme.default.min.css%2bcss%2c_jquery.fancybo" />
    <link href="/Manasya_Project/assets/user/css/A.jquery.mb.YTPlayer.min.css.pagespeed.cf.5LvL8JK871.css" media="all" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="/Manasya_Project/assets/user/css/A.style.css.pagespeed.cf.T0hBavreGe.css">
</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
    <div class="site-wrap">
        <div class="site-mobile-menu site-navbar-target">
            <div class="site-mobile-menu-header">
                <div class="site-mobile-menu-close mt-3">
                    <span class="icon-close2 js-menu-toggle"></span>
                </div>
            </div>
            <div class="site-mobile-menu-body"></div>
        </div>
        <div class="header-top bg-light">


            <div class="site-navbar py-2 js-sticky-header site-navbar-target d-none pl-0 d-lg-block" role="banner">
                <div class="container">

                    <div class="d-flex align-items-center">
                        <div class="col-3 col-lg-1">
                            <a href="/Manasya_Project/assets/user/index-2.html">
                                <img src="/Manasya_Project/assets/user/images/Logo2.png" alt="Image" class="img-fluid">
                            </a>
                        </div>
                        <div class="mr-auto">
                            <nav class="site-navigation position-relative text-right" role="navigation">
                                <ul class="site-menu main-menu js-clone-nav mr-auto d-none pl-0 d-lg-block">
                                    <li>
                                        <a href="<?php echo base_url() . "index.php/user_controller" ?>" class="nav-link text-left">Home</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo base_url() . "index.php/user_controller/about" ?>" class="nav-link text-left">About Us</a>
                                    </li>
                                    <li class="dropdown">
                                        <a href="#" data-toggle="dropdown" class="dropdown-toggle">Our Projects <b class="caret"></b></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="<?php echo base_url() . "index.php/user_controller/project" ?>">Infrastructure</a></li>
                                            <li><a href="<?php echo base_url() . "index.php/user_controller/project_design" ?>">Design & Interior</a></li>
                                            <li><a href="<?php echo base_url() . "index.php/user_controller/project_build" ?>">Build & Renovation</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="<?php echo base_url() . "index.php/user_controller/alat" ?>" class="nav-link text-left">Our Heavy Equipment</a>
                                    </li>
                                </ul>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="intro-section site-blocks-cover innerpage" style="background-image:url(/Manasya_Project/assets/user/images/xhero_1.jpg.pagespeed.ic.2Ma9BcgpmS.jpg)">
            <div class="container">
                <div class="row align-items-center text-center border">
                    <div class="col-lg-12 mt-5" data-aos="fade-up">
                        <h1>Project Us</h1>
                        <p class="text-white text-center">
                            <a href="index-2.html">Home</a>
                            <span class="mx-2">/</span>
                            <span>Our Projects</span>
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="site-section">
            <div class="container">
                <div class="row">
                    <?php
                    $no = 1;
                    foreach ($hasil as $data) {
                    ?>
                        <div class="col-md-6 col-lg-3 mb-4">
                            <div class="project-item">
                                <div class="project-item-contents">
                                    <a href="project-single.html">
                                        <span class="project-item-category"><?php echo $data->projek; ?></span>
                                        <h2 class="project-item-title">
                                            <p><?php echo $data->projek_deskripsi; ?></p>
                                        </h2>
                                        <span class="project-item-category"><?php echo $data->start_date_projek; ?></span>
                                        <br>
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="project-item-category"><?php echo 'to'; ?></span>
                                        <br>
                                        <span class="project-item-category"><?php echo $data->end_date_projek; ?></span>
                                    </a>
                                </div>
                                <?php
                                if ($data->gambar_projek != null) {
                                ?>
                                    <img src="<?php echo base_url() . "assets/admin/projek/" . $data->gambar_projek ?>" alt="Image" style="height:320px;width:100%;" class="img-fluid">
                                <?php
                                } else {
                                ?>
                                    <img src="<?php echo base_url() . "assets/user/images/noimg.jpg" ?>" alt="Image" style="height:320px;width:100%;" class="img-fluid">
                                <?php
                                }
                                ?>
                            </div>
                        </div>
                    <?php
                        $no++;
                    }
                    ?>

                </div>
            </div>
        </div>
        <div class="footer">
            <div class="container">
                <div class="row">
                    <!-- <div class="col-lg-3">
                        <p class="mb-4"><img src="../assets/user/images/xlogo2.png.pagespeed.ic.gRJ5wEBtiM.png" alt="Image" class="img-fluid"></p>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae nemo minima qui dolor, iusto iure.</p>
                        <p><a href="#">Learn More</a></p>
                    </div> -->
                    <div class="col-lg-3">
                        <h3 class="footer-heading"><span>Alamat</span></h3>
                        <ul class="list-unstyled">
                            <p>JL. Sektor VII Blok D. No 32, RT/RW 004/009 Kel. Sudimara Jaya, Kec. Ciledug, Tangerang.</p>
                        </ul>

                    </div>
                    <div class="col-lg-3">
                        <h3 class="footer-heading"><span>Telepon/Fax</span></h3>
                        <ul class="list-unstyled">
                            <p>021- 27565657</p>
                        </ul>




                    </div>
                    <div class="col-lg-3">
                        <h3 class="footer-heading"><span>Email</span></h3>
                        <ul class="list-unstyled">
                            <p>manasya_as@yahoo.co.id</p>
                        </ul>
                    </div>
                    <div class="col-lg-3">
                        <h3 class="footer-heading"><span>Our Social Media</span></h3>
                        <ul class="list-unstyled">
                        <a href="https://www.instagram.com/interior_manasya/"><i class="fa fa-instagram" style="font-size:24px;color:white"></i></a>
                            &nbsp;&nbsp;&nbsp;
                            <a href="https://www.facebook.com/pages/category/Home-Decor/Manasya-Interior-796679360699047/"><i class="fa fa-facebook" style="font-size:24px;color:white"></i></a>
                            
                        </ul>
                    </div>

                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="copyright">
                            <p>
                                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                                Copyright &copy;<script>
                                    document.write(new Date().getFullYear());
                                </script> All rights reserved | This template is made with <i class="icon-heart text-danger" aria-hidden="true"></i> by <a href="https://colorlib.com/" target="_blank">Colorlib</a>
                                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .site-wrap -->
    <!-- loader -->
    <div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px">
            <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
            <circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#ff5e15" /></svg></div>
    <script src="/Manasya_Project/assets/user/js/jquery-3.3.1.min.js.pagespeed.jm.r0B4QCxeCQ.js"></script>
    <script src="/Manasya_Project/assets/user/js/jquery-migrate-3.0.1.min.js%2bjquery-ui.js.pagespeed.jc.f-3El68NVa.js"></script>
    <script>
        eval(mod_pagespeed_JfmHcZreqx);
    </script>
    <script>
        eval(mod_pagespeed_YRfCZUwbaH);
    </script>
    <script src="/Manasya_Project/assets/user/js/popper.min.js"></script>
    <script src="/Manasya_Project/assets/user/js/bootstrap.min.js.pagespeed.jm.MrbHTYgm9G.js"></script>
    <script src="/Manasya_Project/assets/user/js/owl.carousel.min.js%2bjquery.stellar.min.js%2bjquery.countdown.min.js.pagespeed.jc.rq_E4EotLI.js"></script>
    <script>
        eval(mod_pagespeed_2ODPI48w40);
    </script>
    <script>
        eval(mod_pagespeed_MqdEhrSDBp);
    </script>
    <script>
        eval(mod_pagespeed_rXwvamjnbC);
    </script>
    <script src="/Manasya_Project/assets/user/js/bootstrap-datepicker.min.js"></script>
    <script src="/Manasya_Project/assets/user/js/jquery.easing.1.3.js.pagespeed.jm.buIHz7bp97.js"></script>
    <script src="/Manasya_Project/assets/user/js/aos.js"></script>
    <script src="/Manasya_Project/assets/user/js/jquery.fancybox.min.js"></script>
    <script src="/Manasya_Project/assets/user/js/jquery.sticky.js%2bjquery.mb.YTPlayer.min.js%2bmain.js.pagespeed.jc.OcmANEGCPi.js"></script>
    <script>
        eval(mod_pagespeed_Zdjr_JedN2);
    </script>
    <script>
        eval(mod_pagespeed_Q0uwn7jNq8);
    </script>
    <script>
        eval(mod_pagespeed_vSXZOAWUO8);
    </script>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());
        gtag('config', 'UA-23581568-13');
    </script>
</body>

<!-- Mirrored from preview.colorlib.com/theme/engineers/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 23 Nov 2020 02:37:30 GMT -->

</html>