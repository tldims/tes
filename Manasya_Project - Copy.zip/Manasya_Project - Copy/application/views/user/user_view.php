<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from preview.colorlib.com/theme/engineers/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 23 Nov 2020 02:37:14 GMT -->

<head>

    <title>PT MANASYA ANUGERAH SEJAHTERA</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Oswald:300,400,700|Muli:300,400" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/user/fonts%2c_icomoon%2c_style.css%2bcss%2c_bootstrap.min.css%2bcss%2c_jquery-ui.css%2bcss%2c_owl.carousel.min.css%2bcss%2c_owl.theme.default.min.css%2bcss%2c_owl.theme.default.min.css%2bcss%2c_jquery.fancybo" />
    <link href="<?php echo base_url();?>assets/user/css/A.jquery.mb.YTPlayer.min.css.pagespeed.cf.5LvL8JK871.css" media="all" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/user/css/A.style.css.pagespeed.cf.T0hBavreGe.css">
</head>


<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
    <div class="site-wrap">
        <div class="site-mobile-menu site-navbar-target">
            <div class="site-mobile-menu-header">
                <div class="site-mobile-menu-close mt-3">
                    <span class="icon-close2 js-menu-toggle"></span>
                </div>
            </div>
            <div class="site-mobile-menu-body"></div>
        </div>

        <div class="header-top bg-light">
            <div class="d-flex justify-content-end">
                <a href="#" class="d-inline-block d-lg-none site-menu-toggle js-menu-toggle text-black" style="padding-right: 5px;"><span class="icon-menu h3"></span></a>
            </div>

            <div class="site-navbar py-2 js-sticky-header site-navbar-target d-none pl-0 d-lg-block" role="banner">
                <div class="container">
                    <div class="d-flex align-items-center">
                        <div class="col-3 col-lg-1">
                            <a href="<?php echo base_url();?>assets/user/index-2.html">
                                <img src="<?php echo base_url();?>assets/user/images/logo2.png" alt="Image" class="img-fluid">
                            </a>
                        </div>
                        <div class="mr-auto">
                            <nav class="site-navigation position-relative text-right" role="navigation">
                                <ul class="site-menu main-menu js-clone-nav mr-auto d-none pl-0 d-lg-block">
                                    <li>
                                        <a href="<?php echo base_url() . "index.php/user_controller" ?>" class="nav-link text-left">Home</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo base_url() . "index.php/user_controller/about" ?>" class="nav-link text-left">About Us</a>
                                    </li>
                                    <li class="dropdown">
                                        <a href="#" data-toggle="dropdown" class="dropdown-toggle">Our Projects <b class="caret"></b></a>
                                        <ul class="dropdown-menu">
                                            <li><a href="<?php echo base_url() . "index.php/user_controller/project" ?>">Infrastructure</a></li>
                                            <li><a href="<?php echo base_url() . "index.php/user_controller/project_design" ?>">Design & Interior</a></li>
                                            <li><a href="<?php echo base_url() . "index.php/user_controller/project_build" ?>">Build & Renovation</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="<?php echo base_url() . "index.php/user_controller/alat" ?>" class="nav-link text-left">Our Heavy Equipment</a>
                                    </li>
                                </ul>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="hero-slide owl-carousel site-blocks-cover">
            <div class="intro-section" style="background-image: url('<?php echo base_url();?>assets/user/images/home2.png');">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-12 mx-auto text-center" data-aos="fade-up">
                            <h1><strong>PT MANASYA ANUGERAH SEJAHTERA</strong></h1>
                            <p>"The joy of Building Best"</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="intro-section" style="background-image: url('<?php echo base_url();?>assets/user/images/hero_1.jpg');">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-12 mx-auto text-center" data-aos="fade-up">
                            <span class="d-block"></span>
                            <h1><strong>Visi</strong></h1>
                            <p>Menjadikan PT. MANASYA ANUGERAH SEJAHTERA, selalu mendapatkan Prioritas dihati para pelanggan.</p>
                            <br><br>
                            <h1><strong>Misi</strong></h1>
                            <p>Membuat kepuasan bagi para pelanggan sehingga kepercayaan tumbuh dan membuatnya menjadi pelanggan setia.</p>

                            <p>Memberikan kepercayaan dengan berdasarkan kualitas, ketepatan waktu dalam pelaksanaan pekerjaan, serta harga yang competitive.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END slider -->
        <div class="site-section services-1-wrap">
            <div class="container">
                <div class="row mb-5 justify-content-center text-center">
                    <div class="col-lg-5">
                        <h3 class="section-subtitle">What We Do</h3>
                        <h2 class="section-title mb-4 text-black">We Are <strong>Engaged in infrastructure.</strong> We Love What We Do</h2>
                    </div>
                </div>
                <div class="row no-gutters">
                    <div class="col-lg-4 col-md-6">
                        <div class="service-1">
                            <span class="number">01</span>
                            <div>
                                <img src="<?php echo base_url();?>assets/user/images/road.png" width="60" height="60">
                            </div>
                            <div class="service-1-content">
                                <h3 class="service-heading">Pembuatan Jalan</h3>
                                <p>Untuk jalan raya, jalan parkir, jalan perumahan/komplek,dsb yang meliputi pekerjaan pengalian tanah, pembuatan badan jalan,
                                    pemadatan, pengecoran, dan pemasangan grassblock atau dengan Hotmix sesuai dengan keinginan pelanggan dengan hasil yang maksimal
                                    dan tepat waktu sehingga mendapatkan kepuasan dari hasil pekerjaan yang telah dilaksanakan.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="service-1">
                            <span class="number">02</span>
                            <div>
                                <img src="<?php echo base_url();?>assets/user/images/sketch.png" width="60" height="60">
                            </div>
                            <div class="service-1-content">
                                <h3 class="service-heading">Renovasi dan Bangun Baru</h3>
                                <p>Untuk Gedung, Bungalow, Ruko, Rumah, Pabrik. Restaurant. dsb yang meliputi pekerjaan sipil, mechanical & electrical, finishing dan sodium_crypto_aead_aes256gcm_is_available
                                    pekerjaan dari lantai, dinding, sampai atap. Baik itu bangun baru atau renovasi untuk menjadikan area tersebut menjadi lebih baik.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="service-1">
                            <span class="number">03</span>
                            <div>
                                <img src="<?php echo base_url();?>assets/user/images/digger.png" width="60" height="60">
                            </div>
                            <div class="service-1-content">
                                <h3 class="service-heading">Penyewaan Alat Berat</h3>
                                <p>Untuk penggalian tanah, pembuatan kolam renang, pembuatan saluran air, dsb. Kami menyewakan alat berat berupa Exavator Komatsu PC 100,
                                    Exavator Cat PC 100, Exavator Kubota PC 50, dan Exavator Hitachi PC 100.
                                </p>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="row no-gutters">
                    <div class="col-lg-4 col-md-6">
                        <div class="service-1">
                            <span class="number">04</span>
                            <div>
                                <img src="<?php echo base_url();?>assets/user/images/farming.png" width="60" height="60">
                            </div>
                            <div class="service-1-content">
                                <h3 class="service-heading">Penataan Taman</h3>
                                <p>Area pinggir jalan, area pemisah jalan, area perumahan, dsb. Yang meliputi pemilihan tanaman sesuai dengan kebutuhan, dan keinginan konsumen,
                                    pemasangan tanaman di sekitar area yang diperlukan, perawatan tanaman agar dapat tumbuh dan menjadikan kawasan jalan, perumahan, dan taman menjadi kawasan
                                    asri dan terpelihara.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="service-1">
                            <span class="number">05</span>
                            <div>
                                <img src="<?php echo base_url();?>assets/user/images/petrol.png" width="60" height="60">
                            </div>
                            <div class="service-1-content">
                                <h3 class="service-heading">Pembuatan Saluran Air</h3>
                                <p>Untuk gedung dan prasarana lain, yang meliputi pengalian dan peleberan tanah sehingga saluran dapat berfungsi dengan baik</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="service-1">
                            <span class="number">06</span>
                            <div>
                                <img src="<?php echo base_url();?>assets/user/images/living-room.png" width="60" height="60">
                            </div>
                            <div class="service-1-content">
                                <h3 class="service-heading">Design & Interior</h3>
                                <p>Memberikan solusi terbaik dengan design menarik, berkualitas, dan terjangkau. </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END services -->
        <div class="site-section">
            <div class="block-2">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 mb-4 mb-lg-0">
                            <img src="<?php echo base_url();?>assets/user/images/xabout_1.jpg.pagespeed.ic.ZUzahhD3Db.jpg" alt="Image " class="img-fluid img-overlap">
                        </div>
                        <div class="col-lg-5 ml-auto">
                            <h2 class="section-title mb-4">Our History</h2>
                            <p>PT. MANASYA ANUGERAH SEJAHTERA didirikan pada 19 Maret 2014 berdasarkan pada komitmen untuk turut serta dalam pembangunan gedung
                                , sarana dan prasarana di Indonesia melalui jasa konstruksi.
                            </p>
                            <div class="row my-5">
                                <div class="col-lg-12 d-flex align-items-center mb-4">
                                    <span class="line-height-0 flaticon-oil-platform display-4 mr-4 text-primary"></span>
                                    <div>
                                        <h4 class="m-0 h5 text-white">Expert in Buidlings</h4>
                                        <p class="text-white">Berpengalaman pada bidang pembangunan yang sudah terbukti dengan beberapa projek yang sudah ditangani.</p>
                                    </div>
                                </div>
                                <div class="col-lg-12 d-flex align-items-center mb-4">
                                    <span class="line-height-0 flaticon-compass display-4 mr-4 text-primary"></span>
                                    <div>
                                        <h4 class="m-0 h5 text-white">Modern Design</h4>
                                        <p class="text-white">Dengan membangun design yang mengikuti jaman, client akan disuguhi dengan design yang modern.</p>
                                    </div>
                                </div>
                                <div class="col-lg-12 d-flex align-items-center">
                                    <span class="line-height-0 flaticon-planning display-4 mr-4 text-primary"></span>
                                    <div>
                                        <h4 class="m-0 h5 text-white">Leading In Floor Planning</h4>
                                        <p class="text-white">Terbiasa dengan budaya kami yang sangat terstruktur dalam membuat suatu projek, dengan itu diharapkan
                                            projek dapat cepat selesai dengan hasil yang berkualitas.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END block-2 -->
        <!-- <div class="">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 align-self-end">
                        <img src="<?php echo base_url();?>assets/user/images/ximg_transparent.png.pagespeed.ic.VcF7V8SEVj.png" alt="Image" class="img-fluid">
                    </div>
                    <div class="col-lg-7 align-self-center mb-5">
                        <div class="bg-black  quote-form-wrap wrap text-white">
                            <div class="mb-5">
                                <h3 class="section-subtitle">Get A Quote</h3>
                                <h2 class="section-title mb-4">Request A <strong>Quote</strong></h2>
                            </div>
                            <form action="#" class="quote-form">
                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <input type="text" class="form-control" placeholder="Your name*">
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <input type="text" class="form-control" placeholder="Phone number">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <input type="text" class="form-control" placeholder="Your email*">
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <input type="text" class="form-control" placeholder="Subject">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <textarea name="" class="form-control" id="" placeholder="Message*" cols="30" rows="7"></textarea>
                                    </div>
                                    <div class="col-md-6 align-self-end">
                                        <input type="submit" class="btn btn-primary btn-block btn-lg rounded-0" value="Send Message">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->
        <div class="site-section block-3">
            <div class="container">
                <div class="mb-5">
                    <h3 class="section-subtitle">Our Projects Infrastructure</h3>
                    <h2 class="section-title mb-4">Explore Our <strong>Recent Projects</strong></h2>
                </div>
                <div class="projects-carousel-wrap">
                    <div class="owl-carousel owl-slide-3">
                        <?php
                        $no = 1;
                        if ($hasil4 != null) {
                            foreach ($hasil4 as $data) {
                        ?>
                                <div class="project-item">
                                    <div class="project-item-contents">
                                        <a href="#">
                                            <h2 class="project-item-title">
                                                <?php echo $data->projek; ?>
                                            </h2>
                                            <p><?php echo $data->projek_deskripsi; ?></p>
                                            <span class="project-item-category"><?php echo $data->start_date_projek; ?></span>

                                            &nbsp;<span class="project-item-category"><?php echo '-'; ?></span>
                                            &nbsp;
                                            <span class="project-item-category"><?php echo $data->end_date_projek; ?></span>



                                        </a>
                                    </div>
                                    <?php
                                    if ($data->gambar_projek != null) {
                                    ?>
                                        <img src="<?php echo base_url() . "assets/admin/projek/" . $data->gambar_projek ?>" alt="Image" style="height:320px;width:100%;" class="img-fluid">
                                    <?php
                                    } else {
                                    ?>
                                        <img src="<?php echo base_url() . "assets/user/images/noimg.jpg" ?>" alt="Image" style="height:320px;width:100%;" class="img-fluid">
                                    <?php
                                    }
                                    ?>
                                </div>
                            <?php
                                $no++;
                            }
                        } else {
                            ?>
                            <div class="project-item">
                                <div class="project-item-contents">
                                    <a href="#">
                                        <h2 class="project-item-title">
                                            <?php echo 'No data'; ?>
                                        </h2>
                                        <p><?php echo 'No data'; ?></p>
                                        <span class="project-item-category"><?php echo 'No data'; ?></span>

                                        &nbsp;<span class="project-item-category"><?php echo '-'; ?></span>
                                        &nbsp;
                                        <span class="project-item-category"><?php echo 'No data'; ?></span>



                                    </a>
                                </div>
                                <img src="<?php echo base_url() . "assets/user/images/noimg.jpg" ?>" alt="Image" style="height:320px;width:100%;" class="img-fluid">
                            </div>
                        <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="site-section block-3">
            <div class="container">
                <div class="mb-5">
                    <h3 class="section-subtitle">Our Projects Design & Interior</h3>
                    <h2 class="section-title mb-4">Explore Our <strong>Recent Projects</strong></h2>
                </div>
                <div class="projects-carousel-wrap">
                    <div class="owl-carousel owl-slide-3">
                        <?php
                        $no = 1;
                        if ($hasil3 != null) {
                            foreach ($hasil3 as $data) {
                        ?>
                                <div class="project-item">
                                    <div class="project-item-contents">
                                        <a href="#">
                                            <h2 class="project-item-title">
                                                <?php echo $data->projek; ?>
                                            </h2>
                                            <p><?php echo $data->projek_deskripsi; ?></p>
                                            <span class="project-item-category"><?php echo $data->start_date_projek; ?></span>

                                            &nbsp;<span class="project-item-category"><?php echo '-'; ?></span>
                                            &nbsp;
                                            <span class="project-item-category"><?php echo $data->end_date_projek; ?></span>



                                        </a>
                                    </div>
                                    <?php
                                    if ($data->gambar_projek != null) {
                                    ?>
                                        <img src="<?php echo base_url() . "assets/admin/projek/" . $data->gambar_projek ?>" alt="Image" style="height:320px;width:100%;" class="img-fluid">
                                    <?php
                                    } else {
                                    ?>
                                        <img src="<?php echo base_url() . "assets/user/images/noimg.jpg" ?>" alt="Image" style="height:320px;width:100%;" class="img-fluid">
                                    <?php
                                    }
                                    ?>
                                </div>
                            <?php
                                $no++;
                            }
                        } else {
                            ?>
                            <div class="project-item">
                                <div class="project-item-contents">
                                    <a href="#">
                                        <h2 class="project-item-title">
                                            <?php echo 'No data'; ?>
                                        </h2>
                                        <p><?php echo 'No data'; ?></p>
                                        <span class="project-item-category"><?php echo 'No data'; ?></span>

                                        &nbsp;<span class="project-item-category"><?php echo '-'; ?></span>
                                        &nbsp;
                                        <span class="project-item-category"><?php echo 'No data'; ?></span>



                                    </a>
                                </div>
                                <img src="<?php echo base_url() . "assets/user/images/noimg.jpg" ?>" alt="Image" style="height:320px;width:100%;" class="img-fluid">
                            </div>
                        <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="site-section block-3">
            <div class="container">
                <div class="mb-5">
                    <h3 class="section-subtitle">Our Projects Build & Renovation</h3>
                    <h2 class="section-title mb-4">Explore Our <strong>Recent Projects</strong></h2>
                </div>
                <div class="projects-carousel-wrap">
                    <div class="owl-carousel owl-slide-3">
                        <?php
                        $no = 1;
                        if ($hasil5 != null) {
                            foreach ($hasil5 as $data) {
                        ?>
                                <div class="project-item">
                                    <div class="project-item-contents">
                                        <a href="#">
                                            <h2 class="project-item-title">
                                                <?php echo $data->projek; ?>
                                            </h2>
                                            <p><?php echo $data->projek_deskripsi; ?></p>
                                            <span class="project-item-category"><?php echo $data->start_date_projek; ?></span>

                                            &nbsp;<span class="project-item-category"><?php echo '-'; ?></span>
                                            &nbsp;
                                            <span class="project-item-category"><?php echo $data->end_date_projek; ?></span>



                                        </a>
                                    </div>
                                    <?php
                                    if ($data->gambar_projek != null) {
                                    ?>
                                        <img src="<?php echo base_url() . "assets/admin/projek/" . $data->gambar_projek ?>" alt="Image" style="height:320px;width:100%;" class="img-fluid">
                                    <?php
                                    } else {
                                    ?>
                                        <img src="<?php echo base_url() . "assets/user/images/noimg.jpg" ?>" alt="Image" style="height:320px;width:100%;" class="img-fluid">
                                    <?php
                                    }
                                    ?>
                                </div>
                            <?php
                                $no++;
                            }
                        } else {
                            ?>
                            <div class="project-item">
                                <div class="project-item-contents">
                                    <a href="#">
                                        <h2 class="project-item-title">
                                            <?php echo 'No data'; ?>
                                        </h2>
                                        <p><?php echo 'No data'; ?></p>
                                        <span class="project-item-category"><?php echo 'No data'; ?></span>

                                        &nbsp;<span class="project-item-category"><?php echo '-'; ?></span>
                                        &nbsp;
                                        <span class="project-item-category"><?php echo 'No data'; ?></span>



                                    </a>
                                </div>
                                <img src="<?php echo base_url() . "assets/user/images/noimg.jpg" ?>" alt="Image" style="height:320px;width:100%;" class="img-fluid">
                            </div>
                        <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="site-section block-3">
            <div class="container">
                <div class="mb-5">
                    <h3 class="section-subtitle">Our Heavy Equipment</h3>
                    <h2 class="section-title mb-4">Explore Our <strong>Heavy Equipment</strong></h2>
                </div>
                <div class="projects-carousel-wrap">
                    <div class="owl-carousel owl-slide-3">
                        <?php
                        $no = 1;
                        if ($hasil2 != null) {
                            foreach ($hasil2 as $data) {
                        ?>
                                <div class="project-item">
                                    <div class="project-item-contents">
                                        <a href="#">
                                            <h2 class="project-item-title">
                                                <?php echo $data->projek; ?>
                                            </h2>
                                            <p><?php echo $data->projek_deskripsi; ?></p>
                                            <span class="project-item-category"><?php echo $data->start_date_projek; ?></span>

                                            &nbsp;<span class="project-item-category"><?php echo '-'; ?></span>
                                            &nbsp;
                                            <span class="project-item-category"><?php echo $data->end_date_projek; ?></span>



                                        </a>
                                    </div>
                                    <?php
                                    if ($data->gambar_alat != null) {
                                    ?>
                                        <img src="<?php echo base_url() . "assets/admin/alat/" . $data->gambar_alat ?>" alt="Image" style="height:320px;width:100%;" class="img-fluid">
                                    <?php
                                    } else {
                                    ?>
                                        <img src="<?php echo base_url() . "assets/user/images/noimg.jpg" ?>" alt="Image" style="height:320px;width:100%;" class="img-fluid">
                                    <?php
                                    }
                                    ?>
                                </div>
                            <?php
                                $no++;
                            }
                        } else {
                            ?>
                            <div class="project-item">
                                <div class="project-item-contents">
                                    <a href="#">
                                        <h2 class="project-item-title">
                                            <?php echo 'No data'; ?>
                                        </h2>
                                        <p><?php echo 'No data'; ?></p>
                                        <span class="project-item-category"><?php echo 'No data'; ?></span>

                                        &nbsp;<span class="project-item-category"><?php echo '-'; ?></span>
                                        &nbsp;
                                        <span class="project-item-category"><?php echo 'No data'; ?></span>



                                    </a>
                                </div>
                                <img src="<?php echo base_url() . "assets/user/images/noimg.jpg" ?>" alt="Image" style="height:320px;width:100%;" class="img-fluid">
                            </div>
                        <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <!-- <div class="site-section testimonial-wrap">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 mb-5 text-center">
                        <h3 class="section-subtitle">Testimonial</h3>
                        <h2 class="section-title text-black mb-4">What People Says</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-4 mb-md-0">
                        <div class="testimonial">
                            <img src="<?php echo base_url();?>assets/user/images/xperson_3_sq.jpg.pagespeed.ic.T7PrxifB6y.jpg" alt="">
                            <blockquote>
                                <p>&ldquo;Lorem ipsum dolor sit, amet consectetur adipisicing elit. Provident deleniti iusto molestias, dolore vel fugiat ab placeat ea?&rdquo;</p>
                            </blockquote>
                            <p class="client-name">Matt Keygen</p>
                        </div>
                    </div>
                    <div class="col-md-6 mb-4 mb-md-0">
                        <div class="testimonial">
                            <img src="<?php echo base_url();?>assets/user/images/xperson_4_sq.jpg.pagespeed.ic.7kIGzKXZq2.jpg" alt="">
                            <blockquote>
                                <p>&ldquo;Lorem ipsum dolor sit, amet consectetur adipisicing elit. Provident deleniti iusto molestias, dolore vel fugiat ab placeat ea?&rdquo;</p>
                            </blockquote>
                            <p class="client-name">Matt Keygen</p>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->
        <!-- <div class="site-section bg-light">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 mb-5 text-left">
                        <h3 class="section-subtitle">Blog</h3>
                        <h2 class="section-title text-black mb-4">News &amp; Updates</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-4 mb-lg-0 col-lg-4">
                        <div class="blog-entry">
                            <a href="#" class="img-link">
                                <img src="<?php echo base_url();?>assets/user/images/xhero_1.jpg.pagespeed.ic.2Ma9BcgpmS.jpg" alt="Image" class="img-fluid">
                            </a>
                            <div class="blog-entry-contents">
                                <h3><a href="#">Top Companies That Are Best In Industrial Business</a></h3>
                                <div class="meta">Posted by <a href="#">Admin</a> In <a href="#">News</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-4 mb-lg-0 col-lg-4">
                        <div class="blog-entry">
                            <a href="#" class="img-link">
                                <img src="<?php echo base_url();?>assets/user/images/xhero_1.jpg.pagespeed.ic.2Ma9BcgpmS.jpg" alt="Image" class="img-fluid">
                            </a>
                            <div class="blog-entry-contents">
                                <h3><a href="#">Top Companies That Are Best In Industrial Business</a></h3>
                                <div class="meta">Posted by <a href="#">Admin</a> In <a href="#">News</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-4 mb-lg-0 col-lg-4">
                        <div class="blog-entry">
                            <a href="#" class="img-link">
                                <img src="<?php echo base_url();?>assets/user/images/xhero_1.jpg.pagespeed.ic.2Ma9BcgpmS.jpg" alt="Image" class="img-fluid">
                            </a>
                            <div class="blog-entry-contents">
                                <h3><a href="#">Top Companies That Are Best In Industrial Business</a></h3>
                                <div class="meta">Posted by <a href="#">Admin</a> In <a href="#">News</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="py-5 bg-primary block-4">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <h3 class="text-white">Subscribe To Newsletter</h3>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nesciunt, reprehenderit!</p>
                    </div>
                    <div class="col-lg-6">
                        <form action="#" class="form-subscribe d-flex">
                            <input type="text" class="form-control form-control-lg">
                            <input type="submit" class="btn btn-secondary px-4" value="Subcribe">
                        </form>
                    </div>
                </div>
            </div>
        </div> -->
        <div class="footer">
            <div class="container">
                <div class="row">
                    <!-- <div class="col-lg-3">
                        <p class="mb-4"><img src="<?php echo base_url();?>assets/user/images/xlogo2.png.pagespeed.ic.gRJ5wEBtiM.png" alt="Image" class="img-fluid"></p>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae nemo minima qui dolor, iusto iure.</p>
                        <p><a href="#">Learn More</a></p>
                    </div> -->
                    <div class="col-lg-3">
                        <h3 class="footer-heading"><span>Alamat</span></h3>
                        <ul class="list-unstyled">
                            <p>JL. Sektor VII Blok D. No 32, RT/RW 004/009 Kel. Sudimara Jaya, Kec. Ciledug, Tangerang.</p>
                        </ul>

                    </div>
                    <div class="col-lg-3">
                        <h3 class="footer-heading"><span>Telepon/Fax</span></h3>
                        <ul class="list-unstyled">
                            <p>021- 27565657</p>
                        </ul>




                    </div>
                    <div class="col-lg-3">
                        <h3 class="footer-heading"><span>Email</span></h3>
                        <ul class="list-unstyled">
                            <p>manasya_as@yahoo.co.id</p>
                        </ul>
                    </div>
                    <div class="col-lg-3">
                        <h3 class="footer-heading"><span>Our Social Media</span></h3>
                        <ul class="list-unstyled">
                            <a href="https://www.instagram.com/interior_manasya/"><i class="fa fa-instagram" style="font-size:24px;color:white"></i></a>
                            &nbsp;&nbsp;&nbsp;
                            <a href="https://www.facebook.com/pages/category/Home-Decor/Manasya-Interior-796679360699047/"><i class="fa fa-facebook" style="font-size:24px;color:white"></i></a>

                        </ul>
                    </div>

                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="copyright">
                            <p>
                                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                                Copyright &copy;<script>
                                    document.write(new Date().getFullYear());
                                </script> All rights reserved | This template is made with <i class="icon-heart text-danger" aria-hidden="true"></i> by <a href="https://colorlib.com/" target="_blank">Colorlib</a>
                                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .site-wrap -->

    <div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px">
            <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
            <circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#ff5e15" />
        </svg></div>
    <script src="<?php echo base_url();?>assets/user/js/jquery-3.3.1.min.js.pagespeed.jm.r0B4QCxeCQ.js"></script>
<script src="<?php echo base_url();?>assets/user/js/jquery-migrate-3.0.1.min.js%2bjquery-ui.js.pagespeed.jc.f-3El68NVa.js"></script><script>eval(mod_pagespeed_JfmHcZreqx);</script>
<script>eval(mod_pagespeed_YRfCZUwbaH);</script>
<script src="<?php echo base_url();?>assets/user/js/popper.min.js"></script>
<script src="<?php echo base_url();?>assets/user/js/bootstrap.min.js.pagespeed.jm.MrbHTYgm9G.js"></script>
<script src="<?php echo base_url();?>assets/user/js/owl.carousel.min.js%2bjquery.stellar.min.js%2bjquery.countdown.min.js.pagespeed.jc.rq_E4EotLI.js"></script><script>eval(mod_pagespeed_2ODPI48w40);</script>
<script>eval(mod_pagespeed_MqdEhrSDBp);</script>
<script>eval(mod_pagespeed_rXwvamjnbC);</script>
<script src="<?php echo base_url();?>assets/user/js/bootstrap-datepicker.min.js"></script>
<script src="<?php echo base_url();?>assets/user/js/jquery.easing.1.3.js.pagespeed.jm.buIHz7bp97.js"></script>
<script src="<?php echo base_url();?>assets/user/js/aos.js"></script>
<script src="<?php echo base_url();?>assets/user/js/jquery.fancybox.min.js"></script>
<script src="<?php echo base_url();?>assets/user/js/jquery.sticky.js%2bjquery.mb.YTPlayer.min.js%2bmain.js.pagespeed.jc.OcmANEGCPi.js"></script><script>eval(mod_pagespeed_Zdjr_JedN2);</script>
<script>eval(mod_pagespeed_Q0uwn7jNq8);</script>
<script>eval(mod_pagespeed_vSXZOAWUO8);</script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','UA-23581568-13');</script>
</body>

<!-- Mirrored from preview.colorlib.com/theme/engineers/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 23 Nov 2020 02:37:30 GMT -->

</html>