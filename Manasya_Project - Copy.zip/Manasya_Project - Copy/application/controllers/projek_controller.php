<?php

class projek_controller extends CI_Controller
{
    function tambah()
    {


        // meload file model komentar

        $this->load->model('projek_model');

        // menjalankan fungsi tambah pada model
        $this->projek_model->tambah();

        // mengarahkan file ke controller komentar
        // artinya mengarah ke komentar/index
        redirect('projek_controller');


        // meload tampilan komentar_tambah

    }
    function tambah_view()
    {
        $this->load->view('admin/projek_add');
    }

    // fungsi yang pertama kali diload ketika memanggil controller komentar
    function index()
    {
        $this->load->model('projek_model');

        //mengambil nilai pengembalian dari fungsi tampil pada model
        //return yang didapat berupa array dari $hasil
        $data['hasil'] = $this->projek_model->tampil();

        // meload file model komentar


        // mengambil nilai pengambilan dari fungsi tampil pada model
        // return yang ddapat berupa array dari $hasil


        // meload file view komentar_tampil
        // sekaligus memberikan parameter $data
        // yang berisi data $hasil dari fungsi tampil pada model
        //$this->load->view('vendor_view',$data);

        $this->load->view('admin/projek_view', $data);
    }

    // fungsi untuk melakukan penghapusan data
    function delete($id_projek)
    {
        $where = array('id_projek' => $id_projek);
        // meload file model kometar
        $this->load->model('projek_model');

        // menjalankan fungsi hapus pada model
        $this->projek_model->hapus($where, 'msmerk');

        // mengarahlan file ke controller komentar
        // areinya mengarah ke komentar/index
        redirect('projek_controller');
    }
    function delete_projek($INT_ID_projek)
    {

        $this->load->model('projek_model');
        $this->projek_model->delete_projek($INT_ID_projek);
        redirect('projek_controller');
    }

    function undelete_projek($INT_ID_projek)
    {
        $this->load->model('projek_model');
        $this->projek_model->undelete_projek($INT_ID_projek);
        redirect('projek_controller');
    }

    // fungsi untuk melakukan perubahan
    function update_view($id_projek)
    {
        // membaca apakah pada form update sudah dilakukan submit
        // jika belum, maka masuk ke dalam fungsi if

        // meload file model komentar
        $this->load->model('projek_model');

        // menjalankan fungsi ubah_tampil
        // meletakan hasil pencrian pada ubah_tampil di variable $data
        $data['hasil'] = $this->projek_model->ubah_tampil($id_projek);

        // meload file view komentar ubah dengan parameter array $data

        $this->load->view('admin/projek_edit', $data);

        // meload file model komentar


    }
    function update($id_projek)
    {
        $this->load->model('projek_model');

        // menjalankan fungsi ubah pada model
        $this->projek_model->ubah($id_projek);

        // mengarahkan file ke controller komentar
        // artinya mengarah ke komentar/index
        redirect('projek_controller');
    }
}
