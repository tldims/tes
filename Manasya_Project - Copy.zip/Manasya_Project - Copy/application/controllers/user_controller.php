<?php

class user_controller extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		//$this->load->model('Daerah_model','daerah',true);
		//$this->load->database();
	}

	public function index()
	{
		$this->load->model('projek_model');
		$this->load->model('alat_model');

        //mengambil nilai pengembalian dari fungsi tampil pada model
        //return yang didapat berupa array dari $hasil
        $data['hasil2'] = $this->alat_model->tampil();

        //mengambil nilai pengembalian dari fungsi tampil pada model
        //return yang didapat berupa array dari $hasil
		$data['hasil'] = $this->projek_model->tampil();
		$data['hasil3'] = $this->projek_model->tampil_design();
		$data['hasil4'] = $this->projek_model->tampil_building();
		$data['hasil5'] = $this->projek_model->tampil_building_renovation();
        // load view admin/overview.php
		// $data['provinsi']=$this->daerah->getProv();
		// $data['supir']=$this->daerah->getSupir();
		// $data['mobil']=$this->daerah->getMobil();
		// $data['paket']=$this->daerah->getPaket();
		// $this->itunghari('25-10-2018','26-10-2018');
		// $this->getJar('Kesamben');
		$this->load->view("user/user_view",$data);
	}
	public function about()
	{
		// $this->load->model('projek_model');
		// $this->load->model('alat_model');

        // //mengambil nilai pengembalian dari fungsi tampil pada model
        // //return yang didapat berupa array dari $hasil
        // $data['hasil2'] = $this->alat_model->tampil();

        // //mengambil nilai pengembalian dari fungsi tampil pada model
        // //return yang didapat berupa array dari $hasil
        // $data['hasil'] = $this->projek_model->tampil();
        // load view admin/overview.php
		// $data['provinsi']=$this->daerah->getProv();
		// $data['supir']=$this->daerah->getSupir();
		// $data['mobil']=$this->daerah->getMobil();
		// $data['paket']=$this->daerah->getPaket();
		// $this->itunghari('25-10-2018','26-10-2018');
		// $this->getJar('Kesamben');
		$this->load->view("user/about_view");
	}
	public function project()
	{
		 $this->load->model('projek_model');
		// $this->load->model('alat_model');

        // //mengambil nilai pengembalian dari fungsi tampil pada model
        // //return yang didapat berupa array dari $hasil
        // $data['hasil2'] = $this->alat_model->tampil();

        // //mengambil nilai pengembalian dari fungsi tampil pada model
        // //return yang didapat berupa array dari $hasil
        // $data['hasil'] = $this->projek_model->tampil();
        // load view admin/overview.php
		// $data['provinsi']=$this->daerah->getProv();
		// $data['supir']=$this->daerah->getSupir();
		// $data['mobil']=$this->daerah->getMobil();
		// $data['paket']=$this->daerah->getPaket();
		// $this->itunghari('25-10-2018','26-10-2018');
		// $this->getJar('Kesamben');
		$data['hasil'] = $this->projek_model->tampil_building();
		$this->load->view("user/project_view",$data);
	}
	public function project_design()
	{
		 $this->load->model('projek_model');
		// $this->load->model('alat_model');

        // //mengambil nilai pengembalian dari fungsi tampil pada model
        // //return yang didapat berupa array dari $hasil
        // $data['hasil2'] = $this->alat_model->tampil();

        // //mengambil nilai pengembalian dari fungsi tampil pada model
        // //return yang didapat berupa array dari $hasil
        // $data['hasil'] = $this->projek_model->tampil();
        // load view admin/overview.php
		// $data['provinsi']=$this->daerah->getProv();
		// $data['supir']=$this->daerah->getSupir();
		// $data['mobil']=$this->daerah->getMobil();
		// $data['paket']=$this->daerah->getPaket();
		// $this->itunghari('25-10-2018','26-10-2018');
		// $this->getJar('Kesamben');
		$data['hasil'] = $this->projek_model->tampil_design();
		$this->load->view("user/project_design_view",$data);
	}

	public function project_build()
	{
		 $this->load->model('projek_model');
		// $this->load->model('alat_model');

        // //mengambil nilai pengembalian dari fungsi tampil pada model
        // //return yang didapat berupa array dari $hasil
        // $data['hasil2'] = $this->alat_model->tampil();

        // //mengambil nilai pengembalian dari fungsi tampil pada model
        // //return yang didapat berupa array dari $hasil
        // $data['hasil'] = $this->projek_model->tampil();
        // load view admin/overview.php
		// $data['provinsi']=$this->daerah->getProv();
		// $data['supir']=$this->daerah->getSupir();
		// $data['mobil']=$this->daerah->getMobil();
		// $data['paket']=$this->daerah->getPaket();
		// $this->itunghari('25-10-2018','26-10-2018');
		// $this->getJar('Kesamben');
		$data['hasil'] = $this->projek_model->tampil_building_renovation();
		$this->load->view("user/project_build_view",$data);
	}
	public function alat()
	{
		$this->load->model('alat_model');
		// $this->load->model('alat_model');

        // //mengambil nilai pengembalian dari fungsi tampil pada model
        // //return yang didapat berupa array dari $hasil
        // $data['hasil2'] = $this->alat_model->tampil();

        // //mengambil nilai pengembalian dari fungsi tampil pada model
        // //return yang didapat berupa array dari $hasil
        // $data['hasil'] = $this->projek_model->tampil();
        // load view admin/overview.php
		// $data['provinsi']=$this->daerah->getProv();
		// $data['supir']=$this->daerah->getSupir();
		// $data['mobil']=$this->daerah->getMobil();
		// $data['paket']=$this->daerah->getPaket();
		// $this->itunghari('25-10-2018','26-10-2018');
		// $this->getJar('Kesamben');
		$data['hasil2'] = $this->alat_model->tampil();
		$this->load->view("user/alat_view",$data);
    }
}