<?php

class alat_controller extends CI_Controller
{
    function tambah()
    {


        // meload file model komentar

        $this->load->model('alat_model');

        // menjalankan fungsi tambah pada model
        $this->alat_model->tambah();

        // mengarahkan file ke controller komentar
        // artinya mengarah ke komentar/index
        redirect('alat_controller');


        // meload tampilan komentar_tambah

    }
    function tambah_view()
    {
        $this->load->view('admin/alat_add');
    }

    // fungsi yang pertama kali diload ketika memanggil controller komentar
    function index()
    {
        $this->load->model('alat_model');

        //mengambil nilai pengembalian dari fungsi tampil pada model
        //return yang didapat berupa array dari $hasil
        $data['hasil'] = $this->alat_model->tampil();

        // meload file model komentar


        // mengambil nilai pengambilan dari fungsi tampil pada model
        // return yang ddapat berupa array dari $hasil


        // meload file view komentar_tampil
        // sekaligus memberikan parameter $data
        // yang berisi data $hasil dari fungsi tampil pada model
        //$this->load->view('vendor_view',$data);

        $this->load->view('admin/alat_view', $data);
    }

    // fungsi untuk melakukan penghapusan data
    function delete($id_alat)
    {
        $where = array('id_alat' => $id_alat);
        // meload file model kometar
        $this->load->model('alat_model');

        // menjalankan fungsi hapus pada model
        $this->alat_model->hapus($where, 'msmerk');

        // mengarahlan file ke controller komentar
        // areinya mengarah ke komentar/index
        redirect('alat_controller');
    }
    function delete_alat($INT_ID_alat)
    {

        $this->load->model('alat_model');
        $this->alat_model->delete_alat($INT_ID_alat);
        redirect('alat_controller');
    }

    function undelete_alat($INT_ID_alat)
    {
        $this->load->model('alat_model');
        $this->alat_model->undelete_alat($INT_ID_alat);
        redirect('alat_controller');
    }

    // fungsi untuk melakukan perubahan
    function update_view($id_alat)
    {
        // membaca apakah pada form update sudah dilakukan submit
        // jika belum, maka masuk ke dalam fungsi if

        // meload file model komentar
        $this->load->model('alat_model');

        // menjalankan fungsi ubah_tampil
        // meletakan hasil pencrian pada ubah_tampil di variable $data
        $data['hasil'] = $this->alat_model->ubah_tampil($id_alat);

        // meload file view komentar ubah dengan parameter array $data

        $this->load->view('admin/alat_edit', $data);

        // meload file model komentar


    }
    function update($id_alat)
    {
        $this->load->model('alat_model');

        // menjalankan fungsi ubah pada model
        $this->alat_model->ubah($id_alat);

        // mengarahkan file ke controller komentar
        // artinya mengarah ke komentar/index
        redirect('alat_controller');
    }
}
