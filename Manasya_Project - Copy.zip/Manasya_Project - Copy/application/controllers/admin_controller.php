<?php

class admin_controller extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->library('session');
	}

    public function show(){
        $this->load->view("login/login_view");
    }
	public function index()
	{
        // load view admin/overview.php
		$username = $this->input->post('username');
        $password = $this->input->post('password');
        
        if($username == "admin" && $password == "manasya"){
            $this->load->library('session');
			$data_session = array(
				'username' => $username,
				'password' => $password,
			);

			$this->session->set_userdata($data_session);
			$this->load->view('admin/admin_view');
		}
		else
		{
			echo "<script> alert('Login failed username / password incorrect'); window.location.href='/Manasya_Project/index.php/admin_controller/show'; </script>";
		}
	}
	public function admin_page()
	{
		
        // load view admin/overview.php
		$this->load->view('admin/admin_view');
		$this->load->view('admin/dashboard');
		$this->load->view('admin/admin_end');
	}
	// fungsi untuk menambahkan data
	public function logout()
	{
        // load view admin/overview.php
		$this->session->unset_userdata(array('username' => ''));
		redirect('admin/login_controller');
	}
}