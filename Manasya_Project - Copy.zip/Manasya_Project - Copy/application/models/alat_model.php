<?php
	// membuat class baru inherit CI_Model
	/**
	 * 
	 */
	class alat_model extends CI_Model
	{
		
		function getAll($config){  
			$hasilquery=$this->db->get('telepon', $config['per_page'], $this->uri->segment(3));
			if ($hasilquery->num_rows() > 0) {
				foreach ($hasilquery->result() as $value) {
					$data[]=$value;
				}
				return $data;
			}      
		}
		// membuat fungsi melakukan penambahan data pada database
		function tambah()
		{
			
				$extensi = array('png', 'jpg', 'jpeg');
				$nama_file = $_FILES['Foto']['name'];
				$x = explode(".", $nama_file);
				$ext = strtolower(end($x));
				$ukuran = $_FILES['Foto']['size'];
				$file_tmp = $_FILES["Foto"]["tmp_name"];
				if(in_array($ext, $extensi) === true){
					if($ukuran < 999999999999){
						//move_uploaded_file($file_tmp, "assets/Photo/".$nama);
						$pathFileTujuan = DOCALAT.$_FILES["Foto"]["name"];
						copy($file_tmp, $pathFileTujuan);
						$photo = $nama_file;
					}
				}

			// mengambil nama, email, pesan dari view
			
			  
    		 
			
            $nama_alat = $this->input->post('nama_alat');
            $deskripsi_alat = $this->input->post('deskripsi_alat');
			// meletakan isi dari variabel $nama, $email, dan $pesan dalam array
			// 'nama', 'email', 'pesan' adalah nama kolom di tabel pada database
            $data = array('gambar_alat'=>$photo,
            'nama_alat'=>$nama_alat,'deskripsi_alat'=>$deskripsi_alat,'status'=>1);

			// menginput array $data ke dalam tabel komentar pada database
			$this->db->insert('daftar_alat',$data);
		}

		// function untuk membaca data dari database
		function tampil()
		{
			//mengambil data dari tabel komentar di db
			//diletakkan pada variabel $tampil
			$this->load->database();
			$tampil = $this->db->query("SELECT * From daftar_alat");
			//memeriksa jumlah row yang ditemukan pada tabel komentar tidak 0
			if($tampil->num_rows() > 0)
			{
				//perulangan untuk setiap data yang ditemukan
				//akan diletakkan pada variabel $data
				foreach($tampil->result() as $data)
				{
					$hasil[] = $data;
				}
				return $hasil;
			}	
		}

		// fungsi untuk menghapus data pada database dengan parameter $id
		function hapus($where,$table)
		{

			// menghapus data pada database di tabel komentar
			// dengan id sesuai dengan isi data pada variabel $id
			$this->db->where($where);
			$this->db->delete($table);
			// mengarah file ke controller komentar
			// artinya mengarah ke komentar/index
			redirect('alat_controller');


        }
        function delete_alat($id) {
			
            $data = array('status' => 0);
			
            $this->db->where('id_alat', $id);
            $this->db->update("daftar_alat", $data);
        }
        function undelete_alat($id) {
			
            $data = array('status' => 1);
    
            $this->db->where('id_alat', $id);
            $this->db->update("daftar_alat", $data);
        }

		// fungsi untuk menampilkan data yang sudah tersimpan pada database
		// sesuai dengan parameter id yang dilempar pada url
		function ubah_tampil($id_alat)
		{
			// membaca data pada tabel komentar, sesuai dengan id yang dikirimkan
			return $this->db->get_where('daftar_alat', array('id_alat'=>$id_alat))->row();
		}

		// fungsi untuk mengubah data pada database dengan parameter $id
		function ubah($id_alat)
		{
			$nama_file = $_FILES['Foto']['name'];
			// echo $nama_file;
			// exit();
			if($nama_file != NULL){
			//if($_POST["submit"]){
				$extensi = array('png', 'jpg');
				$nama_file = $_FILES['Foto']['name'];
				$x = explode(".", $nama_file);
				$ext = strtolower(end($x));
				$ukuran = $_FILES['Foto']['size'];
				$file_tmp = $_FILES["Foto"]["tmp_name"];
				
				if(in_array($ext, $extensi) === true){
					if($ukuran < 999999999999){
						//move_uploaded_file($file_tmp, "assets/Photo/".$nama);
						$pathFileTujuan = DOCALAT.$_FILES["Foto"]["name"];
						copy($file_tmp, $pathFileTujuan);
						$photo = $nama_file;
					}
				}
			} else {
				$photo = $this->input->post('picture_old');
			}
			// mengambil nama, email, dan pesan dari view
			// lalu diletakan pada variabel $nama,$email,$pesan
			$id_alat = $this->input->post('id_alat');
			$nama_alat = $this->input->post('nama_alat');
            $deskripsi_alat = $this->input->post('deskripsi_alat');
			// meletakan isi dari variabel $nama, $email, dan $pesan dalam array
			// 'nama', 'email', 'pesan' adalah nama kolom di tabel pada database
            $data = array('gambar_alat'=>$photo,
        'nama_alat'=>$nama_alat,'deskripsi_alat'=>$deskripsi_alat);

			// memberikan kondisi bahwa id yang diubah pada database
			// adalah id yang diberikan pada variabel $id
			$this->db->where('id_alat',$id_alat);

			// mengupdate tabel komentar sesuai dengan isian array data
			// dan parameter id pada where
			$this->db->update('daftar_alat',$data);
		}
	}
