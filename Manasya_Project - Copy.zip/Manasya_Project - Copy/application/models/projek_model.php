<?php
	// membuat class baru inherit CI_Model
	/**
	 * 
	 */
	class projek_model extends CI_Model
	{
		
		function getAll($config){  
			$hasilquery=$this->db->get('telepon', $config['per_page'], $this->uri->segment(3));
			if ($hasilquery->num_rows() > 0) {
				foreach ($hasilquery->result() as $value) {
					$data[]=$value;
				}
				return $data;
			}      
		}
		// membuat fungsi melakukan penambahan data pada database
		function tambah()
		{
			
				$extensi = array('png', 'jpg', 'jpeg');
				$nama_file = $_FILES['Foto']['name'];
				$x = explode(".", $nama_file);
				$ext = strtolower(end($x));
				$ukuran = $_FILES['Foto']['size'];
				$file_tmp = $_FILES["Foto"]["tmp_name"];
				if(in_array($ext, $extensi) === true){
					if($ukuran < 999999999999){
						//move_uploaded_file($file_tmp, "assets/Photo/".$nama);
						$pathFileTujuan = DOCPROJEK.$_FILES["Foto"]["name"];
						copy($file_tmp, $pathFileTujuan);
						$photo = $nama_file;
					}
				}

			// mengambil nama, email, pesan dari view
			
			$start_date_projek = $this->input->post('start_date_projek');
			$end_date_projek = $this->input->post('end_date_projek');
			
			$tipe_projek = $this->input->post('tipe_projek');
			
			
			$startDate = date("Y-m-d", strtotime($start_date_projek));
			$endDate = date("Y-m-d", strtotime($end_date_projek));  
    		 
			
            $projek = $this->input->post('projek');
            $projek_deskripsi = $this->input->post('projek_deskripsi');
			// meletakan isi dari variabel $nama, $email, dan $pesan dalam array
			// 'nama', 'email', 'pesan' adalah nama kolom di tabel pada database
			if($end_date_projek == ""){
				$data = array('start_date_projek'=>$startDate,'end_date_projek'=>Null,'tipe_projek'=>$tipe_projek,'gambar_projek'=>$photo,
            'projek'=>$projek,'projek_deskripsi'=>$projek_deskripsi,'status'=>1);
			}else{
				$data = array('start_date_projek'=>$startDate,'end_date_projek'=>$endDate,'tipe_projek'=>$tipe_projek,'gambar_projek'=>$photo,
            'projek'=>$projek,'projek_deskripsi'=>$projek_deskripsi,'status'=>1);
			}
            

			// menginput array $data ke dalam tabel komentar pada database
			$this->db->insert('daftar_projek',$data);
		}

		// function untuk membaca data dari database
		function tampil()
		{
			//mengambil data dari tabel komentar di db
			//diletakkan pada variabel $tampil
			$this->load->database();
			$tampil = $this->db->query("SELECT * From daftar_projek");
			//memeriksa jumlah row yang ditemukan pada tabel komentar tidak 0
			if($tampil->num_rows() > 0)
			{
				//perulangan untuk setiap data yang ditemukan
				//akan diletakkan pada variabel $data
				foreach($tampil->result() as $data)
				{
					$hasil[] = $data;
				}
				return $hasil;
			}	
		}

		function tampil_design()
		{
			//mengambil data dari tabel komentar di db
			//diletakkan pada variabel $tampil
			$this->load->database();
			$tampil = $this->db->query("SELECT * From daftar_projek where tipe_projek = 1");
			//memeriksa jumlah row yang ditemukan pada tabel komentar tidak 0
			if($tampil->num_rows() > 0)
			{
				//perulangan untuk setiap data yang ditemukan
				//akan diletakkan pada variabel $data
				foreach($tampil->result() as $data)
				{
					$hasil[] = $data;
				}
				return $hasil;
			}	
		}

		function tampil_building()
		{
			//mengambil data dari tabel komentar di db
			//diletakkan pada variabel $tampil
			$this->load->database();
			$tampil = $this->db->query("SELECT * From daftar_projek where tipe_projek = 0");
			//memeriksa jumlah row yang ditemukan pada tabel komentar tidak 0
			if($tampil->num_rows() > 0)
			{
				//perulangan untuk setiap data yang ditemukan
				//akan diletakkan pada variabel $data
				foreach($tampil->result() as $data)
				{
					$hasil[] = $data;
				}
				return $hasil;
			}	
		}

		function tampil_building_renovation()
		{
			//mengambil data dari tabel komentar di db
			//diletakkan pada variabel $tampil
			$this->load->database();
			$tampil = $this->db->query("SELECT * From daftar_projek where tipe_projek = 2");
			//memeriksa jumlah row yang ditemukan pada tabel komentar tidak 0
			if($tampil->num_rows() > 0)
			{
				//perulangan untuk setiap data yang ditemukan
				//akan diletakkan pada variabel $data
				foreach($tampil->result() as $data)
				{
					$hasil[] = $data;
				}
				return $hasil;
			}	
		}


		// fungsi untuk menghapus data pada database dengan parameter $id
		function hapus($where,$table)
		{

			// menghapus data pada database di tabel komentar
			// dengan id sesuai dengan isi data pada variabel $id
			$this->db->where($where);
			$this->db->delete($table);
			// mengarah file ke controller komentar
			// artinya mengarah ke komentar/index
			redirect('projek_controller');


        }
        function delete_projek($id) {
			
            $data = array('status' => 0);
			
            $this->db->where('id_projek', $id);
            $this->db->update("daftar_projek", $data);
        }
        function undelete_projek($id) {
			
            $data = array('status' => 1);
    
            $this->db->where('id_projek', $id);
            $this->db->update("daftar_projek", $data);
        }

		// fungsi untuk menampilkan data yang sudah tersimpan pada database
		// sesuai dengan parameter id yang dilempar pada url
		function ubah_tampil($id_projek)
		{
			// membaca data pada tabel komentar, sesuai dengan id yang dikirimkan
			return $this->db->get_where('daftar_projek', array('id_projek'=>$id_projek))->row();
		}

		// fungsi untuk mengubah data pada database dengan parameter $id
		function ubah($id_projek)
		{
			$nama_file = $_FILES['Foto']['name'];
			// echo $nama_file;
			// exit();
			if($nama_file != NULL){
			//if($_POST["submit"]){
				$extensi = array('png', 'jpg');
				$nama_file = $_FILES['Foto']['name'];
				$x = explode(".", $nama_file);
				$ext = strtolower(end($x));
				$ukuran = $_FILES['Foto']['size'];
				$file_tmp = $_FILES["Foto"]["tmp_name"];
				
				if(in_array($ext, $extensi) === true){
					if($ukuran < 999999999999){
						//move_uploaded_file($file_tmp, "assets/Photo/".$nama);
						$pathFileTujuan = DOCPROJEK.$_FILES["Foto"]["name"];
						copy($file_tmp, $pathFileTujuan);
						$photo = $nama_file;
					}
				}
			} else {
				$photo = $this->input->post('picture_old');
			}
			// mengambil nama, email, dan pesan dari view
			// lalu diletakan pada variabel $nama,$email,$pesan
			$id_projek = $this->input->post('id_projek');
			$start_date_projek = $this->input->post('start_date_projek');
            $end_date_projek = $this->input->post('end_date_projek');
            $projek = $this->input->post('projek');
			$projek_deskripsi = $this->input->post('projek_deskripsi');
			$tipe_projek = $this->input->post('tipe_projek');
			$startDate = date("Y-m-d", strtotime($start_date_projek));
			$endDate = date("Y-m-d", strtotime($end_date_projek));  
			// meletakan isi dari variabel $nama, $email, dan $pesan dalam array
			// 'nama', 'email', 'pesan' adalah nama kolom di tabel pada database
			if($end_date_projek == ""){
				$data = array('start_date_projek'=>$startDate,'end_date_projek'=>Null,'tipe_projek'=>$tipe_projek,'gambar_projek'=>$photo,
        'projek'=>$projek,'projek_deskripsi'=>$projek_deskripsi);
			}else{
				$data = array('start_date_projek'=>$startDate,'end_date_projek'=>$endDate,'tipe_projek'=>$tipe_projek,'gambar_projek'=>$photo,
        'projek'=>$projek,'projek_deskripsi'=>$projek_deskripsi);
			}
            

			// memberikan kondisi bahwa id yang diubah pada database
			// adalah id yang diberikan pada variabel $id
			$this->db->where('id_projek',$id_projek);

			// mengupdate tabel komentar sesuai dengan isian array data
			// dan parameter id pada where
			$this->db->update('daftar_projek',$data);
		}
	}
